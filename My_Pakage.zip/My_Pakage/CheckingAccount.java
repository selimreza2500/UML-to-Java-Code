package My_Pakage;

public  class CheckingAccount extends BankAccount{

	private double insufficientFundsFee;

	public CheckingAccount(String owner, double balance, double insufficientFundsFee) {
		super(owner, balance);
		this.insufficientFundsFee = insufficientFundsFee;
	}
	
	public void prossCheck() {
		System.out.println("Remaining Funds = "+insufficientFundsFee);
	}
	
	public void withdrawal() {
		System.out.println("Withdrawal Ammount : "+balance+ "$");
	}
}
