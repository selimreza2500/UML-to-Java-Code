package My_Pakage;

public abstract  class BankAccount {

	private String owner;
	protected double balance;
	public BankAccount(String owner, double balance) {
		
		this.owner = owner;
		this.balance = balance;
	}
	public void deposit() {
		System.out.println("Owner name : "+owner + "\nBalance :"+balance);
	}
	
	abstract void withdrawal();	
	
}
